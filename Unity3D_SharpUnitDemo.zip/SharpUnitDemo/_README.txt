Mark Gants
mark@markgants.com

5 June 2012

This project demonstrates how to integrate SharpUnit with a Unity3D project.
Project has been updated to be compatible with Unity3D 3.5.2.

Instructions:

1. Open project in the Unity 3D editor.
2. Open the "SharpUnityDemo.unity" scene
3. Press play

You should notice that 1 test passes and another test fails.

Please review the source code in this project as well as the SharpUnit solution to figure out how
it all works.

Enjoy!
