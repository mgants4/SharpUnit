/**
 * @file Dummy.cs
 * 
 * Dummy class that we will test with SharpUnit.
 */

using UnityEngine;
using System.Collections;

public class Dummy
{
    
}
